using System;

namespace cLofgrenMinesweeper
{
    public partial class Form1 : Form
    {

        Cell[,] cellGrid = new Cell[10, 10];
        Random random = new Random();
        public event EventHandler<RevealEventArgs> Reveal;

        int verticalOffset = 32;
        int horizontalOffset = 32;
        int spacing = 0;


        int mineNumber = 10;


        public Form1()
        {
            InitializeComponent();
            initializeBoard();
            placeMines(ref cellGrid);
            placeProximityNumbers(ref cellGrid);
            //revealBoard(ref cellGrid);
        }

        private void showStatsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void restartToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }




        public void initializeBoard()
        {
            for (int row = 0; row < cellGrid.GetLength(0); row++)
            {
                for (int col = 0; col < cellGrid.GetLength(1); col++)
                {
                    Cell temp = new Cell();
                    temp.CellClicked += onCellClicked;
                    temp.Size = new Size(24, 24);
                    temp.Location = new Point(horizontalOffset + col * (temp.Width + spacing), verticalOffset + row * (temp.Height + spacing));
                    temp.Margin = new Padding(64);
                    temp.x = col;
                    temp.y = row;

                    cellGrid[row, col] = temp;
                    this.Controls.Add(cellGrid[row, col]);
                }

            }

        }


        public void onClick(object sender, EventArgs e)
        {
            
        }


        public void placeMines(ref Cell[,] cellGrid)
        {
            for(int i = 0; i < mineNumber;  i++)
            {
                int x = random.Next(0, 9);
                int y = random.Next(0, 9);

                if (cellGrid[x, y].getCellTextBox().Text != "M")
                {
                    cellGrid[x, y].getCellTextBox().Text = "M";
                    cellGrid[x, y].getCellTextBox().BackColor = Color.DarkGray;
                }
                else
                {
                    i--;
                }
            } 
        }


        public void placeProximityNumbers(ref Cell[,] cellGrid)
        {
            for (int row = 0; row < cellGrid.GetLength(0); row++)
            {
                for (int col = 0; col < cellGrid.GetLength(1); col++)
                {
                    int mineCount = searchForMines(row, col);

                    //set limit on how many mines will be in one proximity space
                    if (mineCount > 3)
                    {
                        mineCount = 3;
                    }

                    //check value to not override a Mine or a space that has no mines in proximity
                    if(cellGrid[row, col].getCellTextBox().Text != "M" && mineCount != 0)
                    {
                        cellGrid[row, col].getCellTextBox().Text = mineCount.ToString();

                        //change color for proximity spaces
                        if(mineCount == 1)
                        {
                            cellGrid[row, col].getCellTextBox().BackColor = Color.Yellow;
                        }
                        else if(mineCount == 2)
                        {
                            cellGrid[row, col].getCellTextBox().BackColor = Color.Orange;
                        }
                        else if(mineCount == 3)
                        {
                            cellGrid[row, col].getCellTextBox().BackColor = Color.Red;
                        }
                    }
                    
                }

            }
        }

        public int searchForMines(int x, int y)
        {
            int mineCount = 0;

            //check top-left
            if(isInBounds(x - 1, y - 1))
            {
                if(isMine(x - 1, y - 1))
                {
                    mineCount++;
                }
            }

            //check up
            if (isInBounds(x, y - 1))
            {
                if (isMine(x, y - 1))
                {
                    mineCount++;
                }
            }

            //check top-right
            if (isInBounds(x + 1, y - 1))
            {
                if (isMine(x + 1, y - 1))
                {
                    mineCount++;
                }
            }

            //check right
            if (isInBounds(x + 1, y))
            {
                if (isMine(x + 1, y))
                {
                    mineCount++;
                }
            }

            //check bottom-right
            if (isInBounds(x + 1, y + 1))
            {
                if (isMine(x + 1, y + 1))
                {
                    mineCount++;
                }
            }

            //check down
            if (isInBounds(x, y + 1))
            {
                if (isMine(x, y + 1))
                {
                    mineCount++;
                }
            }

            //check bottom-left
            if (isInBounds(x - 1, y + 1))
            {
                if (isMine(x - 1, y + 1))
                {
                    mineCount++;
                }
            }

            //check left
            if (isInBounds(x - 1, y))
            {
                if (isMine(x - 1, y))
                {
                    mineCount++;
                }
            }

            return mineCount;
        }


        public bool isMine(int x, int y)
        {
            bool isMine = false;

            if (cellGrid[x,y].getCellTextBox().Text == "M")
            {
                isMine = true;
            }

            return isMine;
        }

        public bool isInBounds(int x, int y)
        {
            bool isInBounds = true;

            if(x < 0 || x > 9)
            {
                isInBounds = false;
            }

            if (y < 0 || y > 9)
            {
                isInBounds = false;
            }

            return isInBounds;
        }

        public void revealBoard(ref Cell[,] cellGrid)
        {
            for (int row = 0; row < cellGrid.GetLength(0); row++)
            {
                for (int col = 0; col < cellGrid.GetLength(1); col++)
                {
                    cellGrid[row,col].getButton().Visible = false;
                }

            }

        }



        public void onCellClicked(object sender, RevealEventArgs e)
        {
            Cell cell = (Cell)sender;
            int row = e.x;
            int col = e.y;

            

            //check up
            if (isInBounds(col, row - 1))
            {
                if (cell.getCellTextBox().Text == "M")
                {

                }
                else if (cell.getCellTextBox().Text == "1" || cell.getCellTextBox().Text == "2" || cell.getCellTextBox().Text == "3")
                {

                }
                else
                {
                    cellGrid[col, row - 1].performClick();
                }
            }

            //check right
            if (isInBounds(col + 1, row))
            {
                if (cell.getCellTextBox().Text == "M")
                {

                }
                else if (cell.getCellTextBox().Text == "1" || cell.getCellTextBox().Text == "2" || cell.getCellTextBox().Text == "3")
                {

                }
                else
                {
                    cellGrid[col + 1, row].performClick();
                }
            }

            //check down
            if (isInBounds(col, row + 1))
            {
                if (cell.getCellTextBox().Text == "M")
                {

                }
                else if (cell.getCellTextBox().Text == "1" || cell.getCellTextBox().Text == "2" || cell.getCellTextBox().Text == "3")
                {

                }
                else
                {
                    cellGrid[col, row + 1].performClick();
                }
            }

            //check left
            if (isInBounds(col - 1, row))
            {
                if (cell.getCellTextBox().Text == "M")
                {

                }
                else if (cell.getCellTextBox().Text == "1" || cell.getCellTextBox().Text == "2" || cell.getCellTextBox().Text == "3")
                {

                }
                else
                {
                    cellGrid[col - 1, row].performClick();
                }
            }


        }
    }
}
