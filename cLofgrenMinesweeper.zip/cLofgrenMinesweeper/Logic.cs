﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cLofgrenMinesweeper
{
    public class Logic
    {
        FileReader fileReader = new FileReader();

        public Logic()
        {

        }

    }
}
