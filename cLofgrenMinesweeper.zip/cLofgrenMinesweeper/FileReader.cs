﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cLofgrenMinesweeper
{
    
    public class FileReader
    {
        String statsFileName = "minesweeper_stats.txt";
        String winLossRatio;
        String averageTime;
        
        public FileReader() 
        { 
            loadFileContents();
        }



        public void loadFileContents()
        {
            StreamReader sr = new StreamReader(statsFileName);

            winLossRatio = sr.ReadLine();
            averageTime = sr.ReadLine();

            sr.Close();
        }





        public String getWinLossRatio()
        {
            return winLossRatio;
        }

        public void setWinLossRatioAndAverageTime(String winLoss, String time)
        {
            StreamWriter sw = new StreamWriter(statsFileName);

            sw.WriteLine(winLoss);
            sw.WriteLine(time);
            sw.Close();
        }


        public String getAverageTime()
        {
            return averageTime;
        }

        

    }
}
