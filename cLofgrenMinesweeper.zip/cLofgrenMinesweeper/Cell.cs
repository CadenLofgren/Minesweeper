﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cLofgrenMinesweeper
{
    public partial class Cell : UserControl
    {
        public event EventHandler<RevealEventArgs> CellClicked;
        Panel backPanel;
        Button cellButton;
        TextBox cellTextBox;

        public int x { get; set; }
        public int y { get; set; }


        public Cell()
        {
            InitializeComponent();
            initializeButtonAndPanel();
        }

        protected virtual void onCellClicked(object sender, RevealEventArgs e)
        {
            CellClicked?.Invoke(this, e);
        }


        public void initializeButtonAndPanel()
        {
            cellButton = new Button();
            cellButton.Size = new Size(this.Width, this.Height);
            cellButton.Click += OnButtonClick;
            this.Controls.Add(cellButton);

            cellTextBox = new TextBox();
            cellTextBox.Text = "";
            cellTextBox.Size = new Size(this.Width, this.Height);
            cellTextBox.Enabled = false;
            cellTextBox.ReadOnly = true;
            cellTextBox.BackColor = Color.Chartreuse;
            this.Controls.Add(cellTextBox);


            backPanel = new Panel();
            backPanel.BackColor = Color.Chartreuse;
            backPanel.Size = new Size(this.Width, this.Height);
            this.Controls.Add(backPanel);
            


        }


        public void OnButtonClick(object sender, EventArgs e)
        {
            
            ((Button)sender).Visible = false;
            cellClicked();
        }

        public void cellClicked()
        {
            RevealEventArgs e = new RevealEventArgs();
            e.x = this.x;
            e.y = this.y;
            onCellClicked(this, e);
        }

        public void performClick()
        {
            cellButton.PerformClick();
        }

        public TextBox getCellTextBox()
        {
            return cellTextBox;
        }

        public Button getButton() 
        { 
            return cellButton; 
        }
    }
}
